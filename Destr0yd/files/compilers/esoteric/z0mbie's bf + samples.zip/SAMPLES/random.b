+++++++>>>>>++>+<
[
    [>>]+>>+
    [
        -[->>+<[<<<[<<]<<+>>>>[>>]+>-]<[>+<-]]		
        <<<[>>++<<-]>>[>++<-]>>[<+>-]
        <[>+<-[<+>-[-[<-<<+>>>-[>-<-[<+>[-]]]]]]]
        +<<
    ]
    <+<<[->[>+<-]>-[<++>-]]
    >>[-<.[-]<+++++++>>>>]>
]

"Random" byte generator using the Rule 30 automaton.
Readily alterable to display rules 0-255.
Somewhat memory-hungry, naturally.

Turn off any newline translation!

Daniel B. Cristofani (cristofd@hevanet.com)
