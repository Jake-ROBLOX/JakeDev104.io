@echo off
set bcc55=c:\borland\bcc55\
::%BCC55%bin\bcc32.exe -lap -lS:0x10000000 -lSc:0x00010000 -lH:0x10000000 -5 -C  -pr -ff -O2 -I%BCC55%include -L%BCC55%lib -H -H=%TEMP%\1.csm %1.cpp
%BCC55%bin\bcc32.exe -lap -lS:0x00010000 -lH:0x00010000 -5 -C  -pr -ff -O2 -I%BCC55%include -L%BCC55%lib -H -H=%TEMP%\1.csm %1.cpp
del %1.tds
del %1.obj
